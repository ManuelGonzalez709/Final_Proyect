# Servidor PHP

- `index.php` &rightarrow; punto de entrada a la aplicación.

- `conexion.php` &rightarrow; archivo configuración de conexión a la bd.

- `models` &rightarrow; clases que representan los modelos de datos.

- `util` &rightarrow; archivos de utilidad, funciones de autenticacion etc.
- Documentación de los métodos del ``Servidor PHP`` &rightarrow; [Aquí](https://docs.google.com/document/d/15xirvKsTvTRIrOnyu6J2p2J1VUhbQxrHXzpU8EtLHIU/edit?usp=sharing)
